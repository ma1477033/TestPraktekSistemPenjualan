-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Время создания: Окт 30 2020 г., 08:28
-- Версия сервера: 5.5.27
-- Версия PHP: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `db_penjualan`
--

-- --------------------------------------------------------

--
-- Структура таблицы `barang`
--

CREATE TABLE IF NOT EXISTS `barang` (
  `kd_barang` int(11) NOT NULL AUTO_INCREMENT,
  `nama_barang` varchar(20) NOT NULL,
  `harga_beli` varchar(50) NOT NULL,
  `harga_jual` varchar(50) NOT NULL,
  `stok` int(11) NOT NULL,
  `diskon` varchar(10) NOT NULL,
  `keterangan` varchar(50) NOT NULL,
  PRIMARY KEY (`kd_barang`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `barang`
--

INSERT INTO `barang` (`kd_barang`, `nama_barang`, `harga_beli`, `harga_jual`, `stok`, `diskon`, `keterangan`) VALUES
(3, 'Komputer', '1.000.000', '1.500.000', 40, '20%', 'Oke'),
(4, 'Laptop', '1.000.000', '15.000.000', 20, '20%', 'Oke'),
(5, 'Komputer laptop baru', '1.200.000', '1.500.000', 20, '30%', 'Oke');

-- --------------------------------------------------------

--
-- Структура таблицы `pelanggan`
--

CREATE TABLE IF NOT EXISTS `pelanggan` (
  `kode_pelanggan` int(11) NOT NULL AUTO_INCREMENT,
  `nama_pelanggan` varchar(50) NOT NULL,
  `kelamin` varchar(25) NOT NULL,
  `alamat` text NOT NULL,
  `no_telpon` varchar(12) NOT NULL,
  PRIMARY KEY (`kode_pelanggan`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `pelanggan`
--

INSERT INTO `pelanggan` (`kode_pelanggan`, `nama_pelanggan`, `kelamin`, `alamat`, `no_telpon`) VALUES
(1, 'Rangga', 'LAKI-LAKI', 'Pekanbaru', '083186815229'),
(3, 'Dinda', 'PEREMPUAN', 'Pekanbaru', '081234567654');

-- --------------------------------------------------------

--
-- Структура таблицы `pengguna`
--

CREATE TABLE IF NOT EXISTS `pengguna` (
  `kd_pengguna` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(25) DEFAULT NULL,
  `username` varchar(8) NOT NULL,
  `pass` varchar(90) DEFAULT NULL,
  `level` int(11) DEFAULT NULL,
  `keterangan` varchar(15) NOT NULL,
  PRIMARY KEY (`kd_pengguna`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=100004 ;

--
-- Дамп данных таблицы `pengguna`
--

INSERT INTO `pengguna` (`kd_pengguna`, `nama`, `username`, `pass`, `level`, `keterangan`) VALUES
(100001, 'M.Abdullah', 'abdul123', '428a78b4fee47253898d7918c0a09160', 1, 'Pimpinan'),
(100002, 'Dian Pertiwi', 'dnptwktv', '9dd93832520df55aa8243bb9342a0185', 2, 'Admin'),
(100003, 'Inka Selvia', 'inkaselv', 'd858b5b21916222beaf8c8aa8ad19a1b', 3, 'Kasir');

-- --------------------------------------------------------

--
-- Структура таблицы `penjualan`
--

CREATE TABLE IF NOT EXISTS `penjualan` (
  `id_jual` int(11) NOT NULL AUTO_INCREMENT,
  `kode_barang` int(11) NOT NULL,
  `kode_pelanggan` int(11) NOT NULL,
  `jumlah` varchar(50) NOT NULL,
  `keterangan` text NOT NULL,
  `status` tinyint(1) DEFAULT '0',
  `tanggal` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_jual`),
  KEY `kode_barang` (`kode_barang`),
  KEY `kode_pelanggan` (`kode_pelanggan`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Дамп данных таблицы `penjualan`
--

INSERT INTO `penjualan` (`id_jual`, `kode_barang`, `kode_pelanggan`, `jumlah`, `keterangan`, `status`, `tanggal`) VALUES
(3, 3, 1, '2', 'oke', 1, '2018-12-02 15:20:38'),
(4, 3, 1, '3', 'oke', 1, '2018-12-02 15:20:38'),
(5, 4, 3, '2', 'oke banget', 1, '2018-12-02 15:20:38'),
(12, 3, 1, '3', 'oke', 1, '2018-12-04 13:05:52'),
(13, 4, 1, '4', '-', 0, '2020-10-30 07:06:53');

-- --------------------------------------------------------

--
-- Структура таблицы `stok`
--

CREATE TABLE IF NOT EXISTS `stok` (
  `kd_stok` int(11) NOT NULL AUTO_INCREMENT,
  `nama_stok` varchar(25) NOT NULL,
  `jumlah_stok` int(11) NOT NULL,
  PRIMARY KEY (`kd_stok`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `stok`
--

INSERT INTO `stok` (`kd_stok`, `nama_stok`, `jumlah_stok`) VALUES
(2, 'Komputer', 40),
(3, 'Laptop', 20);

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `penjualan`
--
ALTER TABLE `penjualan`
  ADD CONSTRAINT `penjualan_ibfk_1` FOREIGN KEY (`kode_barang`) REFERENCES `barang` (`kd_barang`),
  ADD CONSTRAINT `penjualan_ibfk_2` FOREIGN KEY (`kode_pelanggan`) REFERENCES `pelanggan` (`kode_pelanggan`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
