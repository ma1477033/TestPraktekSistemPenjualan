<div class="container-fluid">
    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="#">Stok</a>
        </li>
        <li class="breadcrumb-item active">Tambah Data Stok</li>
    </ol>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header text-white bg-primary">
                    Tambah Data Stok
                </div>
             <?php echo form_open('Stok/tambah') ?>
               <div class="card-body">
                    <div class="form-group">
                        <label for="nama_bencana">Nama Stok</label>
                    <input type="text" class="form-control" name="nama_stok" required="">
                </div>                
                <div class="form-group">
                        <label for="korban jiwa">Jumlah Stok</label>
                  <input type="number" class="form-control"name="jumlah_stok" required="">
                 </div>                
                <div class="card-footer bg-transparent">
                    <button type="submit" name="submit" class="btn btn-primary">
                        Simpan
                    </button>
                    <a href="<?php echo site_url('Stok') ?>" class="btn btn-danger">Kembali</a>
                </div>
            <?php echo form_close() ?>
            </div>
        </div>
    </div>
</div>