<?php
Class Stok extends CI_Controller{

    function __construct() {
        parent::__construct();
        $this->load->Model('Model_stok');//meload Model_stok
    }

     public function index()
     {
         $data['stok']=$this->Model_stok->show_stok()->result();
         $this->template->load('template','stok/index',$data);
     }//meload Model_stok dan menampilkan seluruh data stok

     public function tambah()
     {
         if(isset($_POST['submit'])){
          $this->Model_stok->add();
          redirect('Stok');
         } else{
           $this->template->load('template','stok/add');
         }
     }//meload Model_stok agar bisa melakukan tambah data stok

     public function edit()
     {
         if(isset($_POST['submit'])){
            $this->Model_stok->update();
            redirect('Stok');
         }else{
        $id             = $this->uri->segment(3);
        $data['stok'] = $this->Model_stok->edit($id)->row_Array();
        $this->template->load('template','stok/edit',$data);
     }
    }//meload Model_stok agar bisa melakukan edit data stok

    public function hapus()
    {
       $id=$this->uri->segment(3);
       $this->db->where('kd_stok',$id);
       $this->db->delete('stok');
       redirect('Stok');
    }//agar dapat menghapus data stok
}

?>