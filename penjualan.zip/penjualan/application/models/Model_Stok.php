<?php
Class Model_Stok extends CI_Model{

    public function show_stok()
    {
        $data=$this->db->get('stok');
        return $data;
    }//mendapatkan data stok dari tabel stok

    public function add()
    {
        $data=[

            'nama_stok' => $this->input->post('nama_stok'),
            'jumlah_stok' => $this->input->post('jumlah_stok')            
         ];
         $this->db->insert('stok',$data);
    }//menginsertkan data stok
    public function edit($id)
    {
        $data=$this->db->get_where('stok',array('kd_stok'=>$id));
        return $data;
    }//menampilkan data stok yang akan diedit berdasarkan id yang dipilih

    public function update()
    {
        $data=[
            'nama_stok' => $this->input->post('nama_stok'),
            'jumlah_stok' => $this->input->post('jumlah_stok')
         ];
         $kd_stok=$this->input->post('kd_stok');
         $this->db->where('kd_stok',$kd_stok);
         $this->db->update('stok',$data);

    }//melakukan update data stok

}
?>